#include "skel.h"

int interfaces[ROUTER_NUM_INTERFACES];


int main(int argc, char *argv[]){	
	setvbuf(stdout, NULL, _IONBF, 0);
	packet m;
	int rc;

	init();
	rtable = malloc(sizeof(struct route_table_entry) * 65000);
	arp_table = malloc(sizeof(struct arp_entry) * 100);

	DIE(rtable == NULL, "memory");
	// rtable_size = read_rtable(rtable);
	rtable_size = parse_route_table();
	parse_arp_table();

	qsort (rtable, rtable_size, sizeof(struct route_table_entry), compare_func);
	for (int i = 0; i < rtable_size; i++){
		fprintf(stderr, "PREFIX: %u NEXT_HOP: %u MASK: %u INTERFACE: %u\n",
						rtable[i].prefix, rtable[i].next_hop, rtable[i].mask, rtable[i].interface);
	}

	/* Students will write code here */

	while (1) {

		rc = get_packet(&m);

		DIE(rc < 0, "get_message");


		struct ether_header *eth_hdr = (struct ether_header *)m.payload;

// --posibil sa fie nevoie ntohs (ether_type)
		if (ntohs(eth_hdr->ether_type) == ETHERTYPE_ARP){
			struct arpPkt *arp_pkt = (struct arpPkt *)
								(m.payload + ETHER_HEADER_LEN);


			/*			WORK IN PROGRES ARP		*/
		
		
									// !!!sanse mari sa crape -- inet_Addr

			/* if ARP packet is for me, i'll process it */
			/* if it's a reply, i'll update arp_table */

			/* if it's reply, search in interfaces table if i have an IP addr
				equals to received ip */
			if (ntohs(arp_pkt->arphdr.arp_operation) == ARP_REPLY){
				if (check_is_my_ip(arp_pkt->target_ip_addr) >= 0 ){
					update_arp_table(arp_pkt, arp_table, &arp_table_len);
				}

				/*else if it's request, search in interfaces table 
				check if i have an ip_addr equals to received ip
				get mac for that ip addr and send reply packet
				*/ 
			} else if (ntohs(arp_pkt->arphdr.arp_operation) == ARP_REQUEST){
				
				int index = check_is_my_ip(arp_pkt->target_ip_addr);
				if (index >= 0){

					uint8_t *local_hw_addr = NULL;
					get_interface_mac(interfaces[index], local_hw_addr);
					// send from, ip_addr which i received the request
					arpPkt *sendReply = pack_send_arp(ARP_REPLY, 
												local_hw_addr,
												arp_pkt->target_ip_addr, 
												arp_pkt->sender_hw_addr, 
												arp_pkt->sender_ip_addr);
					send_arp_reply(interfaces[index], sendReply, eth_hdr, local_hw_addr);				
				}

				}	
			
			/*			WORK IN PROGRES ARP		*/

		} else if (ntohs(eth_hdr->ether_type) == ETHERTYPE_IP){
			struct iphdr *ip_hdr = (struct iphdr *)(m.payload + ETHER_HEADER_LEN);
			struct icmphdr *icmp_hdr = (struct icmphdr *)(m.payload + 
									ETHER_HEADER_LEN + IP_HEADER_LEN);

// create a new packet for ICMP request
			packet pkt;
			init_packet(&pkt);
			pkt.len = ETHER_HEADER_LEN + IP_HEADER_LEN + ICMP_HEADER_LEN;
			pkt.interface = m.interface;

			struct ether_header *eth_icmp = (struct ether_header *)pkt.payload;
			struct iphdr *ip_icmp = (struct iphdr *)(pkt.payload + ETHER_HEADER_LEN);
			struct icmphdr *icmp_req = (struct icmphdr *)(pkt.payload + IP_HEADER_LEN + 
															ETHER_HEADER_LEN);


			memcpy(eth_icmp->ether_shost, eth_hdr->ether_dhost, HW_ADDR_LEN);
			memcpy(eth_icmp->ether_dhost, eth_hdr->ether_shost, HW_ADDR_LEN);
			eth_icmp->ether_type = htons(ETHERTYPE_IP);

			ip_icmp->version = 4;
			ip_icmp->ihl = 5;
			ip_icmp->tos = 0;
			ip_icmp->tot_len = htons(pkt.len - sizeof(struct ether_header));
			ip_icmp->id = htons(ip_hdr->id);                          //htons(getpid());
			ip_icmp->frag_off = 0;
			ip_icmp->ttl = ip_hdr->ttl;
			ip_icmp->protocol = IPPROTO_ICMP;
			// ip_icmp->protocol = 1;	
			// ip_icmp->saddr = get_interface_ip(m.interface);

			//cred ca aici e problema -->trebuie sa fac daca este ip-ul meu 
			ip_icmp->saddr = ip_hdr->daddr;
			ip_icmp->daddr = ip_hdr->saddr;

			ip_icmp->check = 0;
			ip_icmp->check = checksum(ip_icmp, sizeof(struct iphdr));

			icmp_req->code = 0;
			icmp_req->un.echo.id = icmp_hdr->un.echo.id;
			icmp_req->un.echo.sequence = htons(icmp_hdr->un.echo.sequence);     //posibil htons


			if ((icmp_hdr->type == ICMP_ECHO) && 
						(ip_hdr->daddr == inet_addr(get_interface_ip(m.interface)))){
				icmp_req->type = ICMP_ECHOREPLY;
				icmp_req->checksum = 0;
				icmp_req->checksum = checksum(icmp_req, sizeof(struct icmphdr));
				send_packet(pkt.interface, &pkt);
				continue;
			}

			// icmp_hdr->type = ICMP_ECHOREPLY;

			/*Check the checksum */
			if (checksum(ip_hdr, sizeof (struct iphdr)) != 0){
				continue;
			}
			/* Check TTL >= 1 */
			if (ip_hdr->ttl <= 1){
				// send am icmp message back
				icmp_req->type = ICMP_TIME_EXCEEDED;
				icmp_req->checksum = 0;
				icmp_req->checksum = checksum(icmp_req, sizeof(struct icmphdr));
				send_packet(pkt.interface, &pkt);
				
				continue;
			}

			/* Find best matching route (using the function you wrote at TODO 1) */

			struct route_table_entry *best_route;
			best_route = get_best_route(ip_hdr->daddr);
			if (best_route == NULL){
				icmp_req->type = ICMP_DEST_UNREACH;
				icmp_req->checksum = 0;
				icmp_req->checksum = checksum(icmp_req, sizeof(struct icmphdr));
				send_packet(pkt.interface, &pkt);

				continue;
			}

			/* Update TTL and recalculate the checksum */

			(ip_hdr->ttl)--;
			ip_hdr->check = 0;
			ip_hdr-> check = checksum(ip_hdr, sizeof(struct iphdr));
			
			/* TODO 7: Find matching ARP entry and update Ethernet addresses */

			struct arp_entry *dest_entry =  get_arp_entry(ip_hdr->daddr);
			if (dest_entry == NULL){

				/*arp_request and wait -- timeout */
				// ARP_request
				// pack_and_Send
				// send message and push it on queue
				// wait timeout ? 
				// put mac in table 
				// if i got the mac, pop from queue and send
			
			// for reques -- BROADCAST
			// Set destination MAC address: broadcast address
			// memset (dst_mac, 0xff, 6 * sizeof (uint8_t));


			} else {
				memcpy(eth_hdr->ether_dhost, dest_entry->mac, sizeof(dest_entry->mac));
			}

			/* Forward the pachet to best_route->interface */
			send_packet(best_route->interface, &m);

		}

	}
}
